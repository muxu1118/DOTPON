﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

[System.Serializable]
public class AnimationData {
	public AnimationClip clip;
	public string clipName;
	public float speed = 1;
	public float transitionDuration = -1;
	public WrapMode wrapMode;
	public bool applyRootMotion;
	public bool iKOnFeet;
	[HideInInspector] public int timesPlayed = 0;
	[HideInInspector] public float secondsPlayed = 0;
	[HideInInspector] public float length = 0;
	internal UnityEditor.Animations.AnimatorState regular_state;
	internal UnityEditor.Animations.AnimatorState mirror_state;
	internal UnityEditor.Animations.AnimatorState currentState;
}

[RequireComponent (typeof (Animator))]
public class MecanimControl : MonoBehaviour {
	
	public AnimationData defaultAnimation = new AnimationData();
	public AnimationData[] animations = new AnimationData[0];
	public bool debugMode = false;
	public bool alwaysPlay = false;
	public bool overrideRootMotion = false;
	public float defaultTransitionDuration = 0.15f;
	public WrapMode defaultWrapMode = WrapMode.Loop;


	private Animator animator;

	private UnityEditor.Animations.AnimatorController controller;
	private UnityEditor.Animations.AnimatorStateMachine stateMachine;

	private AnimationData currentAnimationData;

	private bool currentMirror;

	public delegate void AnimEvent(AnimationData animationData);
	public static event AnimEvent OnAnimationBegin;
	public static event AnimEvent OnAnimationEnd;
	public static event AnimEvent OnAnimationLoop;

	// UNITY METHODS
	void Awake () {
		animator = gameObject.GetComponent<Animator>();
		controller = new UnityEditor.Animations.AnimatorController();
		controller.AddLayer("Layer1");
		stateMachine = controller.layers[0].stateMachine;

		foreach(AnimationData animData in animations) {
			if (animData.wrapMode == WrapMode.Default) animData.wrapMode = defaultWrapMode;
			animData.clip.wrapMode = animData.wrapMode;
			_addState(animData);
		}

		animator.runtimeAnimatorController = controller;

	}

	void Start(){
		if (defaultAnimation.clip == null && animations.Length > 0){
			SetDefaultClip(animations[0].clip, "Default", animations[0].speed, animations[0].wrapMode, false);
		}

		if (defaultAnimation.clip != null){
			_addState(defaultAnimation);

			foreach(AnimationData animData in animations) {
				if (animData.clip == defaultAnimation.clip)
					defaultAnimation.clip = (AnimationClip) Instantiate(defaultAnimation.clip);
			}
			currentAnimationData = defaultAnimation;
			Play(defaultAnimation, defaultTransitionDuration, 0, false);
		}
	}

	void OnDestroy(){
		Destroy(stateMachine);
		Destroy(controller);
	}

	void FixedUpdate(){
		//WrapMode emulator
		if (currentAnimationData == null) return;
		if (currentAnimationData.secondsPlayed == currentAnimationData.length){
			if (currentAnimationData.clip.wrapMode == WrapMode.Loop || currentAnimationData.clip.wrapMode == WrapMode.PingPong) {
				if (MecanimControl.OnAnimationLoop != null) MecanimControl.OnAnimationLoop(currentAnimationData);
				currentAnimationData.timesPlayed ++;
				
				if (currentAnimationData.clip.wrapMode == WrapMode.Loop) {
					SetCurrentClipPosition(0);
				}
				
				if (currentAnimationData.clip.wrapMode == WrapMode.PingPong) {
					SetSpeed(currentAnimationData.clipName, -currentAnimationData.speed);
					SetCurrentClipPosition(0);
				}
				
			}else if (currentAnimationData.timesPlayed == 0) {
				if (MecanimControl.OnAnimationEnd != null) MecanimControl.OnAnimationEnd(currentAnimationData);
				currentAnimationData.timesPlayed = 1;
				
				if (currentAnimationData.clip.wrapMode == WrapMode.Once && alwaysPlay) {
					Play(defaultAnimation, currentMirror);
				}else if (!alwaysPlay){
					animator.speed = 0;
				}
			}
		}else{
			//currentAnimationData.secondsPlayed += Time.deltaTime * animator.speed * Time.timeScale;
			currentAnimationData.secondsPlayed += (Time.fixedDeltaTime * animator.speed);
			if (currentAnimationData.secondsPlayed > currentAnimationData.length) 
				currentAnimationData.secondsPlayed = currentAnimationData.length;
		}
	}
	
	void OnGUI(){
		//Toggle debug mode to see the live data in action
		if (debugMode) {
			GUI.Box (new Rect (Screen.width - 340,40,340,400), "Animation Data");
			GUI.BeginGroup(new Rect (Screen.width - 330,60,400,400));{
				
				AnimatorClipInfo[] animationInfoArray = animator.GetCurrentAnimatorClipInfo(0);
				foreach (AnimatorClipInfo animationInfo in animationInfoArray){
					AnimatorStateInfo animatorStateInfo = animator.GetCurrentAnimatorStateInfo(0);
					GUILayout.Label(animationInfo.clip.name);
					GUILayout.Label("-Wrap Mode: "+ animationInfo.clip.wrapMode);
					GUILayout.Label("-Is Playing: "+ IsPlaying(animationInfo.clip));
					GUILayout.Label("-Blend Weight: "+ animationInfo.weight);
					GUILayout.Label("-Normalized Time: "+ animatorStateInfo.normalizedTime);
					GUILayout.Label("-Length: "+ animationInfo.clip.length);
					GUILayout.Label("----");
				}

				if (currentAnimationData != null && currentAnimationData.clip != null){
					GUILayout.Label("----");
					GUILayout.Label("Current Animation Data");
					GUILayout.Label("-Current Clip Name: "+ currentAnimationData.clipName);
					GUILayout.Label("-Current Speed: "+ GetSpeed().ToString());
					GUILayout.Label("-Times Played: "+ currentAnimationData.timesPlayed);
					GUILayout.Label("-Seconds Played: "+ currentAnimationData.secondsPlayed);
					GUILayout.Label("-Lengh: "+ currentAnimationData.length);
				}
			}GUI.EndGroup();
		}
	}



	// MECANIM CONTROL METHODS
	private void _addState(AnimationData animData){
		animData.regular_state = stateMachine.AddState(animData.clipName);
		animData.regular_state.motion = animData.clip;
		animData.regular_state.iKOnFeet = animData.iKOnFeet;
		if (animData.speed < 0) animData.regular_state.speed = -1;
		
		animData.mirror_state = stateMachine.AddState(animData.clipName);
		animData.mirror_state.motion = animData.clip;
		animData.mirror_state.iKOnFeet = animData.iKOnFeet;
		animData.mirror_state.mirror = true;
		if (animData.speed < 0) animData.mirror_state.speed = -1;
	}

	public void RemoveClip(string name) {
		AnimationData animData = GetAnimationData(name);
		stateMachine.RemoveState(animData.regular_state);
		stateMachine.RemoveState(animData.mirror_state);
		animData.regular_state = null;
		animData.mirror_state = null;
		
		List<AnimationData> animationDataList = new List<AnimationData>(animations);
		animationDataList.Remove(animData);
		animations = animationDataList.ToArray();

	}

	public void RemoveClip(AnimationClip clip) {
		AnimationData animData = GetAnimationData(clip);
		stateMachine.RemoveState(animData.regular_state);
		stateMachine.RemoveState(animData.mirror_state);
		animData.regular_state = null;
		animData.mirror_state = null;

		List<AnimationData> animationDataList = new List<AnimationData>(animations);
		animationDataList.Remove(animData);
		animations = animationDataList.ToArray();
	}
	
	public void SetDefaultClip(AnimationClip clip, string name, float speed, WrapMode wrapMode, bool mirror) {
		defaultAnimation.clip = (AnimationClip) Instantiate(clip);
		if (wrapMode == WrapMode.Default) wrapMode = defaultWrapMode;
		defaultAnimation.clip.wrapMode = wrapMode;
		defaultAnimation.clipName = name;
		defaultAnimation.speed = speed;
		defaultAnimation.transitionDuration = -1;
		defaultAnimation.wrapMode = wrapMode;

		if (mirror){
			stateMachine.defaultState = defaultAnimation.mirror_state;
		}else{
			stateMachine.defaultState = defaultAnimation.regular_state;
		}
	}
	
	public void AddClip(AnimationClip clip, string newName) {
		AddClip(clip, newName, 1, defaultWrapMode);
	}

	public void AddClip(AnimationClip clip, string newName, float speed, WrapMode wrapMode) {
		if (GetAnimationData(newName) != null) Debug.LogWarning("An animation with the name '"+ newName +"' already exists.");
		AnimationData animData = new AnimationData();
		animData.clip = (AnimationClip) Instantiate(clip);
		if (wrapMode == WrapMode.Default) wrapMode = defaultWrapMode;
		animData.clip.wrapMode = wrapMode;
		animData.clip.name = newName;
		animData.clipName = newName;
		animData.speed = speed;
		//animData.length = clip.length / speed;
		animData.length = clip.length;
		animData.wrapMode = wrapMode;
		
		_addState(animData);

		List<AnimationData> animationDataList = new List<AnimationData>(animations);
		animationDataList.Add(animData);
		animations = animationDataList.ToArray();
	}

	public AnimationData GetAnimationData(string clipName){
		foreach(AnimationData animData in animations){
			if (animData.clipName == clipName){
				return animData;
			}
		}
		if (clipName == defaultAnimation.clipName) return defaultAnimation;
		return null;
	}

	public AnimationData GetAnimationData(AnimationClip clip){
		foreach(AnimationData animData in animations){
			if (animData.clip == clip){
				return animData;
			}
		}
		if (clip == defaultAnimation.clip) return defaultAnimation;
		return null;
	}
	
	public void CrossFade(string clipName, float blendingTime){
		CrossFade(clipName, blendingTime, 0, currentMirror);
	}

	public void CrossFade(string clipName, float blendingTime, float normalizedTime, bool mirror){
		_playAnimation(GetAnimationData(clipName), blendingTime, normalizedTime, mirror);
	}
	
	public void CrossFade(AnimationData animationData, float blendingTime, float normalizedTime, bool mirror){
		_playAnimation(animationData, blendingTime, normalizedTime, mirror);
	}

	public void Play(string clipName, float blendingTime, float normalizedTime, bool mirror){
		_playAnimation(GetAnimationData(clipName), blendingTime, normalizedTime, mirror);
	}
	
	public void Play(AnimationClip clip, float blendingTime, float normalizedTime, bool mirror){
		_playAnimation(GetAnimationData(clip), blendingTime, normalizedTime, mirror);
	}

	public void Play(string clipName, bool mirror){
		_playAnimation(GetAnimationData(clipName), 0, 0, mirror);
	}

	public void Play(string clipName){
		_playAnimation(GetAnimationData(clipName), 0, 0, currentMirror);
	}
	
	public void Play(AnimationClip clip, bool mirror){
		_playAnimation(GetAnimationData(clip), 0, 0, mirror);
	}

	public void Play(AnimationClip clip){
		_playAnimation(GetAnimationData(clip), 0, 0, currentMirror);
	}

	public void Play(AnimationData animationData, bool mirror){
		_playAnimation(animationData, animationData.transitionDuration, 0, mirror);
	}

	public void Play(AnimationData animationData){
		_playAnimation(animationData, animationData.transitionDuration, 0, currentMirror);
	}

	public void Play(AnimationData animationData, float blendingTime, float normalizedTime, bool mirror){
		_playAnimation(animationData, blendingTime, normalizedTime, mirror);
	}

	public void Play(){
		animator.speed = Mathf.Abs(currentAnimationData.speed);
	}

	
	private void _playAnimation(AnimationData targetAnimationData, float blendingTime, float normalizedTime, bool mirror){
		if (targetAnimationData == null || targetAnimationData.clip == null) return;
		//clip.wrapMode = targetAnimationData.wrapMode;

		currentMirror = mirror;
		float newAnimatorSpeed = Mathf.Abs(targetAnimationData.speed);

		if (blendingTime == -1) blendingTime = currentAnimationData.transitionDuration;
		if (blendingTime == -1) blendingTime = defaultTransitionDuration;

		if (blendingTime <= 0 || currentAnimationData == null || currentAnimationData.clip == null){
			if (currentMirror){
				animator.Play(targetAnimationData.mirror_state.nameHash, 0, normalizedTime);
				targetAnimationData.currentState = targetAnimationData.mirror_state;
			}else{
				animator.Play(targetAnimationData.regular_state.nameHash, 0, normalizedTime);
				targetAnimationData.currentState = targetAnimationData.regular_state;
			}
		}else {
			if (currentMirror){
				animator.CrossFade(targetAnimationData.mirror_state.nameHash, blendingTime/newAnimatorSpeed, 0, normalizedTime);
				targetAnimationData.currentState = targetAnimationData.mirror_state;
			}else{
				animator.CrossFade(targetAnimationData.regular_state.nameHash, blendingTime/newAnimatorSpeed, 0, normalizedTime);
				targetAnimationData.currentState = targetAnimationData.regular_state;
			}
		}


		targetAnimationData.timesPlayed = 0;
		targetAnimationData.secondsPlayed = (normalizedTime * targetAnimationData.clip.length) / newAnimatorSpeed;
		targetAnimationData.length = targetAnimationData.clip.length;

		if (overrideRootMotion) animator.applyRootMotion = targetAnimationData.applyRootMotion;

		SetSpeed(newAnimatorSpeed);
		currentAnimationData = targetAnimationData;
		
		if (MecanimControl.OnAnimationBegin != null) MecanimControl.OnAnimationBegin(currentAnimationData);

	}
	
	public bool IsPlaying(string clipName){
		return IsPlaying(GetAnimationData(clipName));
	}
	
	public bool IsPlaying(string clipName, float weight){
		return IsPlaying(GetAnimationData(clipName), weight);
	}

	public bool IsPlaying(AnimationClip clip){
		return IsPlaying(GetAnimationData(clip));
	}
	
	public bool IsPlaying(AnimationClip clip, float weight){
		return IsPlaying(GetAnimationData(clip), weight);
	}
	
	public bool IsPlaying(AnimationData animData){
		return IsPlaying(animData, 0);
	}

	public bool IsPlaying(AnimationData animData, float weight){
		if (animData == null) return false;
		if (currentAnimationData == null) return false;
		if (currentAnimationData == animData && animData.wrapMode == WrapMode.Once && animData.timesPlayed > 0) return false;
		if (currentAnimationData == animData) return true;

		AnimatorClipInfo[] animationInfoArray = animator.GetCurrentAnimatorClipInfo(0);
		foreach (AnimatorClipInfo animationInfo in animationInfoArray){
			if (animData.clip == animationInfo.clip && animationInfo.weight >= weight) return true;
		}
		return false;
	}
	
	public string GetCurrentClipName(){
		return currentAnimationData.clipName;
	}
	
	public AnimationData GetCurrentAnimationData(){
		return currentAnimationData;
	}

	public int GetCurrentClipPlayCount(){
		return currentAnimationData.timesPlayed;
	}
	
	public float GetCurrentClipTime(){
		return currentAnimationData.secondsPlayed;
	}

	public float GetCurrentClipLength(){
		return currentAnimationData.length;
	}

	public void SetCurrentClipPosition(float normalizedTime){
		SetCurrentClipPosition(normalizedTime, false);
	}

	public void SetCurrentClipPosition(float normalizedTime, bool pause){
		//AnimatorStateInfo info = animator.GetCurrentAnimatorStateInfo(0);
		animator.Play(currentAnimationData.currentState.nameHash, 0, normalizedTime);
		currentAnimationData.secondsPlayed = normalizedTime * currentAnimationData.length;
		if (pause) Pause();
	}

	public float GetCurrentClipPosition(){
		//AnimatorStateInfo info = animator.GetCurrentAnimatorStateInfo(0);
		//return info.normalizedTime;
		return currentAnimationData.secondsPlayed/currentAnimationData.length;
	}
	
	public void Stop(){
		Play(defaultAnimation.clip, defaultTransitionDuration, 0, currentMirror);
	}
	
	public void Pause(){
		animator.speed = 0;
	}

	public void SetSpeed(AnimationClip clip, float speed){
		AnimationData animData = GetAnimationData(clip);
		animData.speed = speed;
		if (IsPlaying(clip)) SetSpeed(speed);
	}

	public void SetSpeed(string clipName, float speed){
		AnimationData animData = GetAnimationData(clipName);
		if (animData.speed == speed && animator.speed == Mathf.Abs(speed)) return;

		animData.speed = speed;
		if (IsPlaying(clipName)) SetSpeed(speed);
	}
	
	public void SetSpeed(float speed){
		animator.speed = Mathf.Abs(speed);
	}
	
	public void RestoreSpeed(){
		//SetCurrentClipPosition(GetCurrentClipPosition());
		SetSpeed(currentAnimationData.speed);
	}
	
	public void Rewind(){
		SetSpeed(-currentAnimationData.speed);
	}

	public void SetWrapMode(WrapMode wrapMode){
		defaultWrapMode = wrapMode;
	}
	
	public void SetWrapMode(AnimationData animationData, WrapMode wrapMode){
		animationData.wrapMode = wrapMode;
		animationData.clip.wrapMode = wrapMode;
	}

	public void SetWrapMode(AnimationClip clip, WrapMode wrapMode){
		AnimationData animData = GetAnimationData(clip);
		animData.wrapMode = wrapMode;
		animData.clip.wrapMode = wrapMode;
	}

	public void SetWrapMode(string clipName, WrapMode wrapMode){
		AnimationData animData = GetAnimationData(clipName);
		animData.wrapMode = wrapMode;
		animData.clip.wrapMode = wrapMode;
	}

	public float GetSpeed(AnimationClip clip){
		AnimationData animData = GetAnimationData(clip);
		return animData.speed;
	}

	public float GetSpeed(string clipName){
		AnimationData animData = GetAnimationData(clipName);
		return animData.speed;
	}

	public float GetSpeed(){
		return animator.speed;
	}

	public bool GetMirror(){
		return currentMirror;
	}

	public void SetMirror(bool toggle){
		SetMirror(toggle, 0, false);
	}
	
	public void SetMirror(bool toggle, float blendingTime){
		SetMirror(toggle, blendingTime, false);
	}
	
	public void SetMirror(bool toggle, float blendingTime, bool forceMirror){
		if (currentMirror == toggle && !forceMirror) return;
		
		if (blendingTime == 0) blendingTime = defaultTransitionDuration;
		_playAnimation(currentAnimationData, blendingTime, GetCurrentClipPosition(), toggle);
	}
}
